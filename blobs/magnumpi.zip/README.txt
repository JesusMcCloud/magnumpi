1. Install Xposed http://repo.xposed.info/
2. Install magnum-suite.apk on your device
3. Enable it in Xposed
4. Reboot your phone
5. Connect both your PC and your phone to the same network (USB networking is recommended)
6. Start the Magnum PI app on your phone
7. Launch eve_s-dropper.jar on your PC
8. Select an App to inspect and start it

For more information and a more comprehensive user manual, please visit:
https://github.com/JesusMcCloud/magnumpi
